
import matplotlib.pyplot as plt
import numpy as np
import sympy as sp

# Definiowanie zmiennych
z = sp.symbols('z')

def z_transform(sequence):
    """
    Oblicza transformatę Z dla danego skończonego ciągu liczbowego.
    """
    n = sp.symbols('n', integer=True)
    Z = sum(seq * z**(-n) for n, seq in enumerate(sequence))
    return Z

def transfer_function(coeff_num, coeff_den):
    """
    Wyznacza transformatę funkcji przejścia dla układu liniowego.
    coeff_num: współczynniki licznika (od najwyższego do najniższego stopnia)
    coeff_den: współczynniki mianownika (od najwyższego do najniższego stopnia)
    """
    num = sp.Poly(coeff_num, z)
    den = sp.Poly(coeff_den, z)
    H_z = num / den
    return H_z

def analyze_transfer_function(H_z):
    """
    Analizuje funkcję przejścia: wyznacza zera i bieguny.
    """
    zeros = sp.solvers.solve(H_z.as_numer_denom()[0], z)
    poles = sp.solvers.solve(H_z.as_numer_denom()[1], z)
    return zeros, poles

# Przykład użycia

# 1. Transformata Z dla skończonego ciągu liczbowego
sequence = [1, 2, 3, 4]
Z = z_transform(sequence)
print(f"Transformata Z dla ciągu {sequence} wynosi: {Z}")

# 2. Wyznaczanie transformaty funkcji przejścia
coeff_num = [1, -1]  # licznik (1 - z^-1)
coeff_den = [1, -0.5]  # mianownik (1 - 0.5z^-1)
H_z = transfer_function(coeff_num, coeff_den)
print(f"Funkcja przejścia H(z): {H_z}")

# 3. Analiza transformaty
zeros, poles = analyze_transfer_function(H_z)
print(f"Zera: {zeros}")
print(f"Bieguny: {poles}")


# Definiowanie zmiennych
z = sp.symbols('z')


def z_transform(sequence):
    """
    Oblicza transformatę Z dla danego skończonego ciągu liczbowego.
    """
    n = sp.symbols('n', integer=True)
    Z = sum(seq * z ** (-n) for n, seq in enumerate(sequence))
    return Z


def plot_z_transform(sequence, Z, title):
    """
    Rysuje wykres modułu i fazy transformaty Z dla danego ciągu liczbowego.
    """
    Z_func = sp.lambdify(z, Z, 'numpy')

    # Zakres częstotliwości
    omega = np.linspace(-np.pi, np.pi, 400)
    z_values = np.exp(1j * omega)
    Z_values = Z_func(z_values)

    magnitude = np.abs(Z_values)
    phase = np.angle(Z_values)

    # Tworzenie wykresu
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
    fig.suptitle(title)

    # Moduł
    ax1.plot(omega, magnitude)
    ax1.set_title('Moduł transformaty Z')
    ax1.set_xlabel('ω')
    ax1.set_ylabel('|Z(ω)|')
    ax1.grid(True)

    # Faza
    ax2.plot(omega, phase)
    ax2.set_title('Faza transformaty Z')
    ax2.set_xlabel('ω')
    ax2.set_ylabel('∠Z(ω)')
    ax2.grid(True)

    plt.tight_layout()
    plt.show()


# Przykładowe ciągi liczbowe
sequences = [
    [1, 2, 3, 4],
    [1, -1, 1, -1],
    [1, 0, 0, 0, 1],
    [1, 2, 1, 0, 0, -1, -2, -1]
]

# Przetwarzanie i rysowanie wykresów dla każdego ciągu
for i, sequence in enumerate(sequences):
    Z = z_transform(sequence)
    title = f"Transformata Z dla ciągu {sequence}"
    plot_z_transform(sequence, Z, title)
