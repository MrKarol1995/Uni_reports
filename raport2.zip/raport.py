import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

def funkcja_przykladowa(t):
    return np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 10 * t)

# Parametry sygnału
Fs = 1000  # częstotliwość próbkowania
T = 1 / Fs  # okres próbkowania
t = np.arange(0, 1, T)  # wektor czasu

# Sygnał przykładowy
x = funkcja_przykladowa(t)

# Transformata Fouriera
X = np.fft.fft(x)
freqs = np.fft.fftfreq(len(x), T)

# Transformata falkowa (Haara)
def haar_wavelet_transform(signal):
    coeffs = []
    length = len(signal)
    while length >= 2:
        detail = np.zeros(length)
        for i in range(0, length - 1, 2):
            detail[i // 2] = (signal[i] - signal[i + 1]) / np.sqrt(2)
            detail[(i // 2) + length // 2] = (signal[i] + signal[i + 1]) / np.sqrt(2)
        coeffs.append(detail[:length // 2])
        signal = detail[:length // 2]
        length //= 2
    coeffs.append(signal)
    coeffs.reverse()
    return coeffs

coeffs = haar_wavelet_transform(x)

# Transformata Z
system = signal.TransferFunction([1.0], [1.0, -0.5], dt=T)
w, h = signal.freqz(system.num, system.den, worN=len(t))

# Wykresy
plt.figure(figsize=(12, 12))

# Sygnał czasowy
plt.subplot(4, 1, 1)
plt.plot(t, x)
plt.title('Sygnał czasowy')
plt.xlabel('Czas [s]')
plt.ylabel('Amplituda')

# Transformata Fouriera
plt.subplot(4, 2, 3)
plt.plot(freqs, np.abs(X))
plt.title('Transformata Fouriera')
plt.xlabel('Częstotliwość [Hz]')
plt.ylabel('Amplituda')

# Transformata falkowa
plt.subplot(4, 2, 4)
levels = len(coeffs)
for i, coeff in enumerate(coeffs):
    plt.plot(t[:len(coeff)], coeff + i, label=f'Skala {levels - i}')
plt.title('Transformata falkowa (Haar)')
plt.xlabel('Czas [s]')
plt.ylabel('Współczynniki')
plt.legend()
plt.tight_layout()
plt.show()


# Transformat Z
plt.subplot(4, 1, 3)
plt.plot(w, np.abs(h))
plt.title('Moduł transformaty Z')
plt.xlabel('Częstotliwość [rad/s]')
plt.ylabel('Amplituda')

plt.tight_layout()
plt.show()
